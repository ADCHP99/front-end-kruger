import React from "react";

const ACTIVIDAD_API_BASE_URL="http://localhost:9090/api/actividad";

class ActividadServicio{
    
    getActividades(){
        return axios.get(ACTIVIDAD_API_BASE_URL);
}
    crearActividad(actividad){
        return axios.post(ACTIVIDAD_API_BASE_URL, actividad);
    }
    getActividadById(actividadId){
        return axios.get(ACTIVIDAD_API_BASE_URL + '/' + actividadId);
    }
    actualizarActividad(actividad, actividadId){
        return axios.put(ACTIVIDAD_API_BASE_URL + '/' + actividadId, actividad);
    }

    eliminarActividad(actividadId){
        return axios.delete(ACTIVIDAD_API_BASE_URL + '/' + actividadId);
    }
}
export default new ActividadServicio();
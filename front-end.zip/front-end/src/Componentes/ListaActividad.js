import React from "react";
import ActividadServicio from "../Servicios/ActividadServicio";
import "bootstrap/dist/css/bootstrap.css";

class ListaActividadComponente {
  constructor(props) {
    super(props);
    this.state = {
      actividades: [],
    };
    this.adddActividad = this.addActividad.bind(this);
    this.editActividad = this.editActividad.bind(this);
    this.deleteActividad = this.deleteActividad.bind(this);
  }

  deleteActividad(id) {
    ActividadServicio.eliminarActividad(id).then((res) => {
      this.setState({
        actividades: this.state.actividades.filter(
          (actividad) => actividad.id !== id
        ),
      });
    });
  }

  viewActividad(id) {
    this.props.history.push(`/view-actividad/${id}`);
  }
  editActividad(id) {
    this.props.history.push(`/add-actividad/${id}`);
  }
  componentDidMount() {
    ActividadServicio.getActividades().then((res) => {
      this.setState({ actividades: res.data });
    });
  }
  addActividad() {
    this.props.history.push("/add-actividad/_add");
  }
  render() {
    return (
      <div>
        <h2 className="text-center">actividad List</h2>
        <div className="row">
          <button className="btn btn-primary" onClick={this.addACTIVIDAD}>
            {" "}
            Add ACTIVIDAD
          </button>
        </div>
        <br />
        <div class="container text-center">
          <table class="table">
            <thead>
              <tr>
                <th> ACTIVIDAD id</th>
                <th> ACTIVIDAD nombre</th>
                <th> ACTIVIDAD descripcion</th>
                <th> ACTIVIDAD fechaInicio</th>
                <th> ACTIVIDAD fechaFin</th>
                <th> ACTIVIDAD tiempoEstimado</th>
                <th> ACTIVIDAD archivo</th>
                <th> ACTIVIDAD recurso</th>
                <th> Actions</th>
              </tr>
            </thead>
            <tbody>
              {this.state.actividad.map((actividad) => (
                <tr key={actividad.id}>
                  <td> {actividad.nombre} </td>
                  <td> {actividad.descripcion}</td>
                  <td> {actividad.fechaInicio}</td>
                  <td> {actividad.fechaFin} </td>
                  <td> {actividad.tiempoEstimado}</td>
                  <td> {actividad.archivo}</td>
                  <td> {actividad.recurso}</td>
                  <td>
                    <button
                      onClick={() => this.editACTIVIDAD(actividad.id)}
                      className="btn btn-info"
                    >
                      Update{" "}
                    </button>
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() => this.deleteACTIVIDAD(actividad.id)}
                      className="btn btn-danger"
                    >
                      Delete{" "}
                    </button>
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() => this.viewACTIVIDAD(actividad.id)}
                      className="btn btn-info"
                    >
                      View{" "}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>

          </table>
        </div>
      </div>
    );
  }
}
export default ListaActividadComponente
